from setuptools import setup

setup(
    name='fetch_currency',
    version='0.1',
    packages=['fixxer'],
    url='',
    license='',
    author='Armin',
    author_email='Arminbiklarii@gmail.com',
    description='thos project get data from fixer site ',
    zip_safe=False
)